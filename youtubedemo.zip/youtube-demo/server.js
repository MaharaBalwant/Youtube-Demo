var express = require('express');
var cors = require('cors');
var app = express();
var mysql = require('mysql');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({'extended':'true'})); 
app.use(bodyParser.json({ type: '*/*' }));

app.use(cors(
	{
		"Access-Control-Allow-Credentials":"true",
		"Access-Control-Allow-Origin": "*",
		"Access-Control-Allow-Methods": "GET,HEAD,PUT,PATCH,POST,DELETE",
		"Access-Control-Allow-Headers":"Origin, X-Requested-With, Content-Type, Accept, Authorization, Content-Type"
	}
));

var con = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "youtubedemo"
});

con.on('error', function(err) {
  console.log("[mysql error]",err);
});

app.post('/add_videolist', function (req, res) {
	var records = [[req.body.key, req.body.title, req.body.thumbnail]];
	con.getConnection(function (err, connection) {
		if (err) 
			throw err;
		connection.query("INSERT INTO videoslist (videokey, title, thumbnail) VALUES ?", [records], function (err, result, fields) {
			connection.release();
			if (err) 
				throw err;
			res.send(JSON.stringify(result));
		});
	});
});

app.post('/update_videolist', function (req, res) {
	var records = [[req.body.key, req.body.title, req.body.thumbnail]];
	con.getConnection(function (err, connection) {
		if (err) 
			throw err;
		connection.query("UPDATE videoslist SET title='"+req.body.title+"', thumbnail='"+req.body.thumbnail+"' WHERE videokey='"+req.params.key+"' ", function (err, result, fields) {
			connection.release();
			if (err) 
				throw err;
			res.send(JSON.stringify(result));
		});
	});
});

app.get('/key/:keyValue', function (req, res) {
	con.getConnection(function (err, connection) {
		if (err) 
			throw err;
		connection.query("SELECT * FROM videoslist WHERE videokey='"+req.params.keyValue+"' " , function (err, result, fields) {
			connection.release();
			if (err) 
				throw err;
			res.send(JSON.stringify(result));
		});
	});
});

app.listen(8082);